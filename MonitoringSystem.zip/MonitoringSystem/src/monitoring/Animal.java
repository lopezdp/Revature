/**
 *
 */
package monitoring;
import java.beans.ConstructorProperties;
import java.io.*;

/**
 * @author LopezDP
 *
 */
public class Animal {
	private String species;
	private String name;
	private int age;
	private String health;
	private String feedSchedule;
	private String alert;

	@ConstructorProperties({"species", "name", "age", "health", "feedSchedule", "alert"})
	public Animal(String species, String name, int age, String health, String feedSched, String alert) {
		this.species = species;
		this.name = name;
		this.age = age;
		this.health = health;
		this.feedSchedule = feedSchedule;
		this.alert = alert;
	}

	// Accessor Methods
	public String getSpecies() {
        return this.species;
    }

	public String getName() {
        return this.name;
    }

	public int getAge() {
        return this.age;
    }

	public String getHealth() {
        return this.health;
    }

	public String getFeedSched() {
        return this.feedSchedule;
    }

	public String getAlert() {
        return this.alert;
    }

	// Mutator Methods
	public void setSpecies(String species) {
        this.species = species;
    }

	public void setName(String name) {
        this.name = name;
    }

	public void setAge(int age) {
        this.age = age;
    }

	public void setHealth(String health) {
        this.health = health;
    }

	public void setFeedSched(String feedSched) {
        this.feedSchedule = feedSched;
    }

	public void setAlert(String alert) {
        this.alert = alert;
    }


}
